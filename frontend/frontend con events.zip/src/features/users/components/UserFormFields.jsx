import { UserIcon, PhoneIcon, EnvelopeIcon, LockClosedIcon } from '@heroicons/react/24/outline';

export default function UserFormFields({ form, onChange, isEditing }) {
  return (
    <>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-sm text-slate-600 flex items-center gap-1 mb-1">
            <UserIcon className="w-4 h-4" /> Nombre
          </label>
          <input
            name="nombre"
            value={form.nombre}
            onChange={onChange}
            className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder="Nombre"
          />
        </div>
        <div>
          <label className="text-sm text-slate-600 flex items-center gap-1 mb-1">
            <UserIcon className="w-4 h-4" /> Apellido
          </label>
          <input
            name="apellido"
            value={form.apellido}
            onChange={onChange}
            className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder="Apellido"
          />
        </div>
      </div>

      <div>
        <label className="text-sm text-slate-600 flex items-center gap-1 mb-1">
          <PhoneIcon className="w-4 h-4" /> Teléfono
        </label>
        <input
          name="telefono"
          value={form.telefono}
          onChange={onChange}
          className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          placeholder="0000-0000"
        />
      </div>

      <div>
        <label className="text-sm text-slate-600 flex items-center gap-1 mb-1">
          <EnvelopeIcon className="w-4 h-4" /> Correo electrónico
        </label>
        <input
          type="email"
          name="email"
          value={form.email}
          onChange={onChange}
          className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          placeholder="correo@ejemplo.com"
        />
      </div>

      <div>
        <label className="text-sm text-slate-600 flex items-center gap-1 mb-1">
          <LockClosedIcon className="w-4 h-4" /> Contraseña
          {isEditing && <span className="text-xs text-slate-400">(dejar en blanco para no cambiarla)</span>}
        </label>
        <input
          type="password"
          name="password"
          value={form.password}
          onChange={onChange}
          className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          placeholder={isEditing ? '••••••••' : 'Mínimo 6 caracteres'}
        />
      </div>
    </>
  );
}